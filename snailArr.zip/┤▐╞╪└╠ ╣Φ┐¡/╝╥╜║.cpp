#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int i, xcnt = 0, ycnt = -1, n = 0, rl, t = 1, num = 1, ct = 0;
	printf("������ �迭�� ����� ���Դϴ�. ���� �Է�: ");
	scanf_s("%d", &n);
	int **snail = (int**)malloc(sizeof(int*)*n);
	for (i = 0; i < n; i++)
		snail[i] = (int*)malloc(sizeof(int)*n);
	rl = n;
	while (rl >= 0)
	{
		for (i = 0; i < rl; i++)
		{
			ycnt += t;
			snail[xcnt][ycnt] = num;
			num++;
		}
		rl--;
		for (i = 0; i < rl; i++)
		{
			xcnt += t;
			snail[xcnt][ycnt] = num;
			num++;
		}
		t = t*-1;
	}
	for (i = 0; i < n*n; i++)
	{
		printf("%4d", snail[i / n][i % n]);
		ct++;
		if (ct%n == 0)
			puts("");
	}
	for (i = 0; i < n; i++)
		free(snail[i]);
	free(snail);
	return 0;
}
