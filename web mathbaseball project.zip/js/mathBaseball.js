/*
제  목: 숫자야구
작성자: 강백준
작성일: 
*/
$(function(){
function randomnumber()                                      //랜덤으로 네 자리 수 반환
{
	var a, b, c, d, res;
	do{
		a=Math.floor(Math.random()*(9-1+1))+1;
		b=Math.floor(Math.random()*(9-1+1))+1;
		c=Math.floor(Math.random()*(9-1+1))+1;
		d=Math.floor(Math.random()*(9-1+1))+1;
	}while((a==b)||(a==c)||(a==d)||(b==c)||(b==d)||(c==d));
	
	res=1000*a+100*b+10*c+d;
	return res;
};
function mathbaseball(num_orig, num_cont)
{
	var i = 0, j = 0;
	var temp_s = 0, temp_b = 0;
	var orig =
	[
		num_orig % 10,
		Math.floor((num_orig % 100 - num_orig % 10) / 10),
		Math.floor(num_orig / 100) - Math.floor(num_orig / 1000) * 10,
		Math.floor(num_orig / 1000)
	];                                                         //orig에 num_orig의 각 자릿수 저장
	var cont =
	[
		num_cont % 10,
		Math.floor((num_cont % 100 - num_cont % 10) / 10),
		Math.floor(num_cont / 100) - Math.floor(num_cont / 1000) * 10,
		Math.floor(num_cont / 1000)
	];                                                         //cont에 num_cont의 각 자릿수 저장
	for (i = 0; i < 4; i++)
	{
		for (j = 0; j < 4; j++)                                //자릿수끼리 비교
		{
			if ((i == j) && (orig[i] == cont[j]))              //자리 같고 숫자 같으면
			{
				temp_s++;                                      //스트라이크
			}
			else if ((i != j) && (orig[i] == cont[j]))                  //자리 다르고 숫자 같으면
			{
				temp_b++;                                      //볼
			}
		}
	}
	if (temp_s == 4){
		alert("홈런!!!");
		return 1;
	}
	else{
		list_ptc=$("#history_ptc").html();
		$("#history_ptc").html(list_ptc+"<li>"+$("#in").val()+": "+temp_s+"스트라이크, "+temp_b+"볼!</li>");		//스트라이크와 볼 개수 출력
		return 0;
	}
};
var mynum=0;
var yournum=0;
var choice=1, temp=0;
var result;
var list_all, list_ptc;
alert("숫자야구 게임을 시작합니다.\n컴퓨터가 정한 네 자리 수를 기준으로 자릿수와 숫자가 모두 같으면 스트라이크, 자릿수는 다른데 들어 있는 숫자 중 같은 게 있으면 볼, 스트라이크도 볼도 없으면 아웃, 컴퓨터가 정한 네 자리 수를 맞히면 홈런입니다. 홈런을 목표로 열심히 맞혀 보세요!\n숫자끼리 겹치지 않고 0이 들어가지 않는  네 자리 자연수를 입력해 주세요. ");
mynum = randomnumber();
$("#submit").on("click", function(){
	$(this).css("color", "red");
	yournum=$("#in").val();
	result=mathbaseball(mynum, yournum);
	return false;
});
});